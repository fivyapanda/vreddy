import { Component, OnInit } from '@angular/core';
import { IDepartment } from 'src/app/department/department';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})
export class DepartmentComponent implements OnInit {

  department : IDepartment[] =[{
    deptid : '100CSE',
    deptname : 'computer science',
    deptstr : 500,
  },
  { deptid : '101MECH',
    deptname : 'Mechanical',
    deptstr : 650},
    
    { deptid : '102EEE',
    deptname : 'Eelectrical',
    deptstr : 500},

      { deptid : '103ECE',
      deptname : 'Electronics',
      deptstr : 500}

];

  constructor() { }

  ngOnInit() {
  }
delete(dept : IDepartment)
{
  let arr =this.department.filter(p=> p.deptid!=dept.deptid);
  this.department=arr;
}
}